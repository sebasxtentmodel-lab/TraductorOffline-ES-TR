# Traductor Offline ES ↔ TR

Proyecto Android centrado exclusivamente en Español ↔ Turco.

## Qué hace

- Traducción de texto ES → TR y TR → ES mediante ML Kit on-device.
- Descarga/uso local de los modelos de traducción.
- Reconocimiento de voz offline mediante Vosk.
- Modelos Vosk español y turco descargables una sola vez desde la app.
- Texto reconocido se envía al motor de traducción local.
- Síntesis de voz mediante Android TextToSpeech.
- Cambio rápido de dirección.
- Sin cuenta, servidor propio, anuncios ni suscripción.

## Offline real

La traducción funciona localmente una vez descargado el modelo de traducción. La primera preparación del modelo requiere conexión porque ML Kit distribuye sus modelos bajo demanda.

Para voz, la primera instalación de cada modelo Vosk requiere conexión. Después el reconocimiento se ejecuta localmente en el teléfono.

ML Kit documenta los modelos de traducción on-device y la descarga dinámica; Vosk publica modelos pequeños específicos para español y turco para dispositivos móviles.

## GitHub Actions

Sube este proyecto a un repositorio y ejecuta:

Actions → Build APK → Run workflow

El artefacto generado es `TraductorOffline-ES-TR-debug`.

## Modelos de voz

Español: `vosk-model-small-es-0.42` (~39 MB)
Turco: `vosk-model-small-tr-0.3` (~35 MB)

Los modelos no están dentro del APK para mantenerlo ligero.
