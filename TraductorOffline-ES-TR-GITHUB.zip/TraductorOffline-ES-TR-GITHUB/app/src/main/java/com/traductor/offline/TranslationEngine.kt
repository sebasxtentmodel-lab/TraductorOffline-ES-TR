package com.traductor.offline

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslationEngine {
    private var translator: Translator? = null

    private fun codeToMl(code: String): String = when (code) {
        "es" -> TranslateLanguage.SPANISH
        "tr" -> TranslateLanguage.TURKISH
        else -> error("Idioma no permitido: $code")
    }

    fun prepare(source: String, target: String, onReady: () -> Unit, onError: (Exception) -> Unit) {
        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(codeToMl(source))
            .setTargetLanguage(codeToMl(target))
            .build()
        translator = Translation.getClient(options)
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { onReady() }
            .addOnFailureListener { onError(it) }
    }

    fun translate(text: String, onSuccess: (String) -> Unit, onError: (Exception) -> Unit) {
        val t = translator ?: run { onError(IllegalStateException("Modelo no preparado")); return }
        t.translate(text).addOnSuccessListener(onSuccess).addOnFailureListener(onError)
    }

    fun close() { translator?.close(); translator = null }

    fun downloadedModels(onResult: (Set<TranslateRemoteModel>) -> Unit) {
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener(onResult)
    }
}
