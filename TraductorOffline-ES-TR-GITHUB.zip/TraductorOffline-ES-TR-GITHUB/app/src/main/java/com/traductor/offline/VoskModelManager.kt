package com.traductor.offline

import android.content.Context
import kotlinx.coroutines.*
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class VoskModelManager(private val context: Context) {
    data class ModelInfo(val code: String, val name: String, val url: String)

    companion object {
        val ES = ModelInfo("es", "Español", "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip")
        val TR = ModelInfo("tr", "Turco", "https://alphacephei.com/vosk/models/vosk-model-small-tr-0.3.zip")
    }

    private val root = File(context.filesDir, "vosk-models")
    fun directory(code: String) = File(root, code)
    fun isInstalled(code: String) = directory(code).exists() && File(directory(code), "am/final.mdl").exists()

    suspend fun download(info: ModelInfo, progress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        root.mkdirs()
        val zip = File(root, info.code + ".zip")
        val conn = (URL(info.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 60_000; requestMethod = "GET"
        }
        conn.connect()
        if (conn.responseCode !in 200..299) error("Descarga HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        BufferedInputStream(conn.inputStream).use { input ->
            FileOutputStream(zip).use { out ->
                val buf = ByteArray(64 * 1024); var done = 0L; var n: Int
                while (input.read(buf).also { n = it } >= 0) {
                    if (n == 0) continue
                    out.write(buf, 0, n); done += n
                    if (total > 0) progress(((done * 100) / total).toInt())
                }
            }
        }
        conn.disconnect()
        val tmp = File(root, info.code + "-extract")
        if (tmp.exists()) tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val target = File(tmp, entry.name)
                if (!target.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) error("ZIP inválido")
                if (entry.isDirectory) target.mkdirs() else {
                    target.parentFile?.mkdirs(); FileOutputStream(target).use { out -> zis.copyTo(out) }
                }
                entry = zis.nextEntry
            }
        }
        val modelDir = tmp.listFiles()?.firstOrNull { it.isDirectory } ?: error("Modelo no encontrado en ZIP")
        val finalDir = directory(info.code)
        if (finalDir.exists()) finalDir.deleteRecursively()
        modelDir.renameTo(finalDir)
        tmp.deleteRecursively(); zip.delete()
    }
}
