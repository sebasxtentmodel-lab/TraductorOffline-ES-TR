package com.traductor.offline

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale
import java.util.concurrent.Executors
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity(), RecognitionListener {
    private lateinit var source: Spinner
    private lateinit var target: Spinner
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var modelsStatus: TextView
    private lateinit var mic: Button

    private val engine = TranslationEngine()
    private lateinit var modelManager: VoskModelManager
    private var voskModel: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private lateinit var tts: TextToSpeech
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val pool = Executors.newSingleThreadExecutor()

    private val langs = arrayOf("Español", "Turco")
    private val codes = arrayOf("es", "tr")
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        modelManager = VoskModelManager(this)
        bindViews()
        setupLanguageSelectors()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) refreshStatus("Listo") }
        refreshModelStatus()
        prepareTranslation()
    }

    private fun bindViews() {
        source = findViewById(R.id.sourceSpinner); target = findViewById(R.id.targetSpinner)
        input = findViewById(R.id.inputText); output = findViewById(R.id.outputText)
        status = findViewById(R.id.status); modelsStatus = findViewById(R.id.modelsStatus)
        mic = findViewById(R.id.micButton)
        findViewById<Button>(R.id.translateButton).setOnClickListener { translate() }
        findViewById<Button>(R.id.swapButton).setOnClickListener { swapLanguages() }
        findViewById<Button>(R.id.speakButton).setOnClickListener { speak() }
        mic.setOnClickListener { toggleMic() }
        findViewById<Button>(R.id.downloadSourceModel).setOnClickListener { downloadVoiceModel() }
    }

    private fun setupLanguageSelectors() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs)
        source.adapter = adapter; target.adapter = adapter; target.setSelection(1)
        source.onItemSelectedListener = SimpleItemListener { prepareTranslation() }
        target.onItemSelectedListener = SimpleItemListener { prepareTranslation() }
    }

    private fun prepareTranslation() {
        val s = codes[source.selectedItemPosition]; val t = codes[target.selectedItemPosition]
        if (s == t) return
        refreshStatus("Preparando modelo ES↔TR…")
        engine.prepare(s, t, { refreshStatus("Traductor listo — funciona sin conexión con el modelo instalado") }, { refreshStatus("Modelo de traducción no disponible: ${it.message}") })
    }

    private fun translate() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || busy) return
        busy = true; refreshStatus("Traduciendo…")
        engine.translate(text, { result -> busy = false; output.text = result; refreshStatus("Listo — traducción local") }, { busy = false; refreshStatus("Error: ${it.message}") })
    }

    private fun swapLanguages() {
        val a = source.selectedItemPosition; source.setSelection(target.selectedItemPosition); target.setSelection(a)
        val old = input.text.toString(); input.setText(output.text); output.text = old.ifBlank { "—" }
    }

    private fun downloadVoiceModel() {
        val info = if (codes[source.selectedItemPosition] == "es") VoskModelManager.ES else VoskModelManager.TR
        if (modelManager.isInstalled(info.code)) { refreshModelStatus(); return }
        mic.isEnabled = false; modelsStatus.text = "Descargando ${info.name}: 0%"
        scope.launch {
            try {
                modelManager.download(info) { p -> runOnUiThread { modelsStatus.text = "Descargando ${info.name}: $p%" } }
                modelsStatus.text = "Modelo ${info.name} instalado. Ya puede reconocerse voz sin Internet."
            } catch (e: Exception) { modelsStatus.text = "Error al descargar: ${e.message}" }
            finally { mic.isEnabled = true; refreshModelStatus() }
        }
    }

    private fun refreshModelStatus() {
        val es = if (modelManager.isInstalled("es")) "✓" else "—"
        val tr = if (modelManager.isInstalled("tr")) "✓" else "—"
        modelsStatus.text = "Voz offline — Español $es   Turco $tr"
    }

    private fun toggleMic() {
        if (speechService != null) { stopMic(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val code = codes[source.selectedItemPosition]
        if (!modelManager.isInstalled(code)) { modelsStatus.text = "Descarga primero el modelo de voz de ${langs[source.selectedItemPosition]}."; return }
        mic.text = "■ Detener voz"; refreshStatus("Escuchando offline…")
        pool.execute {
            try {
                voskModel = Model(modelManager.directory(code).absolutePath)
                recognizer = Recognizer(voskModel, 16000f)
                speechService = SpeechService(recognizer, 16000f)
                speechService!!.startListening(this)
            } catch (e: Exception) { runOnUiThread { mic.text = "🎙 Hablar offline"; refreshStatus("Error de micrófono: ${e.message}") } }
        }
    }

    private fun stopMic() { speechService?.stop(); speechService?.shutdown(); speechService = null; recognizer?.close(); recognizer = null; voskModel?.close(); voskModel = null; mic.text = "🎙 Hablar offline"; refreshStatus("Voz detenida") }

    override fun onPartialResult(hypothesis: String) { try { val text = JSONObject(hypothesis).optString("partial"); if (text.isNotBlank()) runOnUiThread { input.setText(text); input.setSelection(input.length()) } } catch (_: Exception) {} }
    override fun onResult(hypothesis: String) { try { val text = JSONObject(hypothesis).optString("text"); if (text.isNotBlank()) runOnUiThread { input.setText(text); translate() } } catch (_: Exception) {} }
    override fun onFinalResult(hypothesis: String) { onResult(hypothesis) }
    override fun onError(exception: Exception) { runOnUiThread { refreshStatus("Voz: ${exception.message}"); stopMic() } }
    override fun onTimeout() { runOnUiThread { stopMic() } }

    private fun speak() {
        val text = output.text.toString().trim(); if (text.isEmpty() || text == "—") return
        val locale = if (codes[target.selectedItemPosition] == "es") Locale("es", "CO") else Locale("tr", "TR")
        tts.language = locale; tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "translation")
    }

    private fun refreshStatus(text: String) { status.text = text }
    override fun onDestroy() { stopMic(); tts.stop(); tts.shutdown(); engine.close(); scope.cancel(); pool.shutdownNow(); super.onDestroy() }

    private class SimpleItemListener(val action: () -> Unit) : android.widget.AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) = action()
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
    }
}
