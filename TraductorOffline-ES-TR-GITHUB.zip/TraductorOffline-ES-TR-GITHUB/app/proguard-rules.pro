# Vosk/ML Kit do not require custom rules for this debug-oriented project.
