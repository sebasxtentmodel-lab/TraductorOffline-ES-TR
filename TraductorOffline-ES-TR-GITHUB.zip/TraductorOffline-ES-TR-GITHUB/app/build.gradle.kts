plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.traductor.offline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.traductor.offline.estr"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Traducción en el dispositivo. Los modelos se descargan una vez y después funcionan localmente.
    implementation("com.google.mlkit:translate:17.0.3")

    // Reconocimiento de voz offline.
    implementation("com.alphacephei:vosk-android:0.3.45")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
